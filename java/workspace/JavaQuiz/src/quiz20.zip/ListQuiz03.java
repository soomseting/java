package quiz20;

import java.util.*;

public class ListQuiz03 {
	public static void main(String[] args) {

		/*
		 * 회원정보 프로그램 시뮬레이터
		 * 
		 * 무한반복문안에서 메뉴를 입력받고, 해당 메뉴에 알맞은 내용을 채워 넣어주면 됩니다.
		 * 
		 * 메뉴 1. 유저등록, 2. 전체회원정보출력, 3. 회원정보검색, 4. 회원정보삭제, 5. 프로그램종료
		 * 
		 * 1. 스캐너로 name,age입력받아서 User객체를 리스트에 추가. 2. 모든 회원 정보를 출력하면 됩니다. 3. 찾을 이름을 입력
		 * 받아서, 이름이 있으면, 이름과 나이를 출력해 줍니다. 찾는 이름이 없으면 "~~님은 목록에 없습니다"를 출력합니다. 4. 삭제할 이름을
		 * 입력받아서, 동일한 이름을 가진 회원이 있으면 User를 삭제 5. 종료
		 */
		Scanner sc = new Scanner(System.in);
		List<User> list = new ArrayList<User>();
		while (true) {
			try {
				System.out.println("메뉴를 입력하세요");
				System.out.println("메뉴 1. 유저등록, 2. 전체회원정보출력, 3. 회원정보검색, 4. 회원정보삭제, 5. 프로그램종료");
				int a = sc.nextInt();
				if (a == 1) {
					System.out.print("회원이름 입력:");
					String name = sc.next();
					System.out.print("회원나이 입력:");
					int age = sc.nextInt();
					list.add(new User(name, age));
				} else if (a == 2) {
					for (User u : list) {
						System.out.println(u.getName());
						System.out.println(u.getAge());
						System.out.println("============================");
					}
				} else if (a == 3) {
					System.out.print("검색할 이름을 입력하세요:");
					String str = sc.next();
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getName().equals(str)) {
							System.out.println(list.get(i).getName());
							System.out.println(list.get(i).getAge());
							sc.nextLine();
						} else {
							System.out.println("검색하신 " + str + "님은 목록에 없습니다.");
						}
					}
				} else if (a == 4) {
					System.out.print("삭제할 이름을 입력하세요:");
					String str = sc.next();
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getName().equals(str)) {
							list.remove(i);
							System.out.println("삭제되었습니다");
						} else {
							System.out.println("검색하신 " + str + "님은 목록에 없습니다.");
						}
					}
				} else if (a == 5) {
					System.out.println("프로그램을 종료합니다");
					break;
				}
			} catch (Exception e) {
				System.out.println("메뉴에서 선택해 주세요");
				sc.nextLine();
			}
		}
	}
}
