package quiz20;

public class User<T> {
	private String name;
	private int age;

	public User() {
	
	}
	public User(String name, int age) {
		super();
		this.name = name;
		this.age = age;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
}
